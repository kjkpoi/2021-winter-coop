public class Vertex {
    private int x = -1;
    private int y = -1;
    private boolean obstacle = false;
    private boolean gem = false;
    
    private int maxGem = 0;

    public int getX() { 
        return x; 
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public boolean getObstacle() {
        return obstacle;
    }

    public void setObstacle(boolean obstacle) {
        this.obstacle = obstacle;
    }

    public boolean getGem() {
        return gem;
    }

    public void setGem(boolean gem) {
        this.gem = gem;
    }

    public int getMaxGem() {
        return maxGem;
    }

    public void increaseMaxGem(int maxGem) {
        this.maxGem = maxGem;
    }


}
