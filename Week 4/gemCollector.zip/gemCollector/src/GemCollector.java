import java.util.Stack;

public class GemCollector {
    Vertex[][] map;
    int sizeY;
    int sizeX;
    Point startPoint;
    Point endPoint;
    Stack<PointWithMap> dfsStack = new Stack<>();

    int answerGem = -1;
    boolean answerPath[][];

    public GemCollector(Vertex[][] map, Point startPoint, Point endPoint) {
        this.sizeY = map.length;
        this.sizeX = map[0].length;
        this.map = map;
        this.startPoint = startPoint;
        this.endPoint = endPoint;

        this.answerPath = new boolean[sizeY][sizeX];
    }

    public int collect() {

        // Initialize map. No visited vertex.
        boolean[][] initVisitedMap = new boolean[sizeY][sizeX];
        for (int i = 0; i < sizeY; ++i) {
            for (int j = 0; j < sizeX; ++j) {
                initVisitedMap[i][j] = false;
            }
        }

        PointWithMap startPointWithMap = new PointWithMap(startPoint, initVisitedMap);
        dfsStack.push(startPointWithMap);

        int dy[] = {-1, 0, 1, 0};
        int dx[] = {0, -1, 0, 1};

        System.out.print("endPoint: " + endPoint.getY());
        System.out.print("endPoint: " + endPoint.getX());

        while(!dfsStack.empty()) {
            PointWithMap currentPointWithMap = dfsStack.pop();
            Point currentPoint = currentPointWithMap.getPoint();
            int currentY = currentPoint.getY();
            int currentX = currentPoint.getX();
            System.out.println("POP: "+ currentY + ", " + currentX);
            
            Vertex currentInfo = map[currentY][currentX];
        
            boolean[][] currentMap = currentPointWithMap.getMap();

            // Skip the case of visited vertex.
            if (currentMap[currentY][currentX]) {
                continue;
            }

            // In the case of not visited vertex, set the vertex to visited and search.
            boolean[][] newMap = currentMap;
            newMap[currentY][currentX] = true;

            for(int index = 0; index < 4; ++index) {
                int nextY = currentY + dy[index];
                int nextX = currentX + dx[index];

                // Out of index
                if (nextY == -1 || nextY == sizeY || nextX == -1 || nextX == sizeX) {
                    continue;
                }

                // Avoid obstacle
                if (map[nextY][nextX].getObstacle()){
                    continue;
                }
                
                if (newMap[nextY][nextX]){
                    continue;
                }

                if (nextY == endPoint.getY() && nextX == endPoint.getX()) {
                    continue;
                }


                // Increase maximun gem if there is a gem in current vertex.
                if (currentInfo.getGem()) {
                    if (map[currentY][currentX].getMaxGem() + 1 > map[nextY][nextX].getMaxGem()) {
                        map[nextY][nextX].increaseMaxGem(map[currentY][currentX].getMaxGem() + 1);
                        if (nextY == endPoint.getY() && nextX == endPoint.getX()) {
                            System.out.println("HERE");
                            answerGem = map[currentY][currentX].getMaxGem() + 1;
                            answerPath = newMap;
                            answerPath[endPoint.getY()][endPoint.getX()] = true;
                        }
                    }
                } else {
                    if (map[currentY][currentX].getMaxGem() > map[nextY][nextX].getMaxGem()) {
                        map[nextY][nextX].increaseMaxGem(map[currentY][currentX].getMaxGem());
                        if (nextY == endPoint.getY() && nextX == endPoint.getX()) {
                            System.out.println("HERE");
                            answerGem = map[currentY][currentX].getMaxGem();
                            answerPath = newMap;
                            answerPath[endPoint.getY()][endPoint.getX()] = true;
                        }
                    }
                }

                Point newPoint = new Point(nextY, nextX);
                PointWithMap newPointWithMap = new PointWithMap(newPoint, newMap);
                dfsStack.push(newPointWithMap);

                

            }
            

        }

        return answerGem;

    }


}
