import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int sizeY = sc.nextInt();
        int sizeX = sc.nextInt();
        System.out.println(sizeY + " "+ sizeX);
        sc.nextLine();

        Vertex[][] map = new Vertex[sizeY][sizeX];
        Point startPoint = new Point();
        Point endPoint = new Point();

        for (int i = 0; i < sizeY; i++) {
            for (int j = 0; j < sizeX; j++) {
                map[i][j] = new Vertex();
                map[i][j].setX(j);
                map[i][j].setY(i);
            }
        }

        for (int i = 0; i < sizeY; ++i) {
            String nextLine = sc.nextLine();
            for (int j = 0; j < sizeX; ++j) {
                char input = nextLine.charAt(j);
                if (input == '!') {
                    map[i][j].setObstacle(true);
                } else if (input == '*') {
                    map[i][j].setGem(true);
                } else if (input == 's') {
                    startPoint.setX(j);
                    startPoint.setY(i);
                } else if (input == 'e') {
                    endPoint.setX(j);
                    endPoint.setY(i);
                } else {
                    assert(false);
                }
            }
        }

        sc.close();

        // for (int i = 0; i < sizeY; ++i) {
        //     for (int j = 0; j < sizeX; ++j) {
        //         System.out.println("(" + map[i][j].y + ", " + map[i][j].x + ") ");
        //     }
        //     System.out.println("---------------------");
        // }

        GemCollector gemCollector = new GemCollector(map, startPoint, endPoint);
        int answer = gemCollector.collect();
        System.out.println(answer);
    }
}
