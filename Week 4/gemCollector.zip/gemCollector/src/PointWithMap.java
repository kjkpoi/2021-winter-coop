public class PointWithMap {
    private Point point;
    private boolean[][] map;

    public PointWithMap(Point point, boolean[][] map) {
        this.point = point;
        this.map = map;
    }

    public Point getPoint() {
        return point;
    }
    
    public boolean[][] getMap() {
        return map;
    }
}

