@SuppressWarnings("serial")
public class ProfixNotationInputException extends Exception {
    public ProfixNotationInputException(String msg) {
        super(msg);
    }
}
