import org.junit.Test;

public class ProfixNoationSolverTest {
    

}
