import java.util.Scanner;

// Take input and run profix notation solver.
// And then prints the answer of the arithmetic expression.
public class App {
  public static void main(String[] args) throws Exception {
    Scanner sc = new Scanner(System.in);
    String arithmeticExpression;

    arithmeticExpression = sc.nextLine();
    sc.close();
    
    ProfixNotationSolver profixNotationSolver = new ProfixNotationSolver(arithmeticExpression);

    double answer = profixNotationSolver.calculate();
    System.out.println("Answer : " + answer);

    return;
  }
}
